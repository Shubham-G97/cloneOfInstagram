
module.exports={
    mongoUrl:"mongodb+srv://shubham123yg:b5qOfdmHMMqjVnyL@cluster0.6n1qmvk.mongodb.net/?retryWrites=true&w=majority",
    Jwt_secret:"asdfdsdfkwopqr"
}

//in jwt_secret we have passed random 10 to 12 words