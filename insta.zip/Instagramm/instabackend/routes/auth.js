const express=require('express')
const router=express.Router()
const mongoose=require('mongoose')
const USER=mongoose.model('USER')
const jwt=require('jsonwebtoken')
const requireLogin=require('../middlewares/requireLogin')
const {Jwt_secret}=require('../keys')

const bcrypt=require('bcrypt')
router.get('/',(req,res)=>{
    res.send('helo')
})



router.post('/signup',(req,res)=>{
   const {name,username,email,password}=req.body
   if(!name || !username || !email || !password){
  return  res.status(422).json('Please add all the fields.')
   }
   USER.findOne({$or:[{email:email},{username:username}]}).then((saveduser)=>{
    if(saveduser){
        return res.status(422).json({error:`user already exist 
        with that email`})
    }
    bcrypt.hash(password,12).then((hashedPassword)=>{
        const user=new USER({
            name,
            email,
            username,
            password:hashedPassword 
           })
           user.save()
           .then((user)=>{
            res.json({message:"saved successfully"})
           }).catch(err=>console.log(err))
    })
   
   })
  
})

router.post('/signin',(req,res)=>{
    const {email, password}=req.body
    if(!email || !password){
        return res.status(422).json({error:`Please enter email and
        password`})
    }
    //we only do for email as we have hashed the password so we
    //retreive that with different method
    USER.findOne({email:email}).then((saveduser)=>{
        if(!saveduser){
return res.status(422).json({error:'Invalid email'})
        }
        bcrypt.compare(password,saveduser.password)
      .then((match)=>{
        if(match){
            // return res.status(200).json
            // ({message:'signed in successfully'})
            const token=jwt.sign({_id:saveduser.id},Jwt_secret)
            res.json(token)
            console.log(token)
        }else{
            return res.status(422).json
            ({error:'invalid password'})
        }
      })
      .catch(err=>console.log(err))

    })
})
module.exports=router