import React from "react";
import "./Navbar.css";
import { Link } from "react-router-dom";
function Navbar() {
  return (
    <>
      <div id="head">Navbar</div>
      <div className="linkers">
        <Link to="/signup">
          <li>sign up</li>
        </Link>
        <Link to="/signin">
          <li>sign in</li>
        </Link>
        <Link to="/profile">
          <li>profile</li>
        </Link>
        <Link to="/createPost">
          <span class="material-symbols-outlined">add_a_photo</span>
        </Link>
      </div>
    </>
  );
}
export default Navbar;
