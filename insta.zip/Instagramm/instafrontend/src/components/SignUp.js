import React,{useEffect,useState} from "react";
import { Link, useNavigate } from "react-router-dom";
import {toast } from 'react-toastify';
function SignUp() {
  const navigate=useNavigate()
 const [name,setName]=useState('')
 const [username,setUsername]=useState('')
 const [email,setEmail]=useState('')
 const [password,setPassword]=useState('')

//toast functions
const notifyA=(msg)=>toast.error(msg)
const notifyB=(msg)=>toast.success(msg)

const emailregex=/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/
const passwordregex= /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/ 
const postData=()=>{

  if(!emailregex.test(email)){
    return notifyA('invalid email')
  }else if(!passwordregex.test(password)){
    return notifyA(`Password must contain atleast 8 characters,
    including atleast one number , one smallcase and one uppercase
    letter and atleast one specialcharacters`)
  }

 fetch("http://localhost:5000/signup",{
  method:"post",
  headers:{
    "Content-Type":"application/json"
  },
  body:JSON.stringify({
    name:name,
    username:username,
    email:email,
    password:password
  })
 }).then(res=>res.json())
 .then(data=>{
  if(data.error){
    notifyA(data.error)
  }else{
    notifyB(data.message)
    navigate('/signin')
  }
  console.log(data)})
 }
  return (
    <div className="signUp">
    <center>
      <div className="form-container">
        <p className="loginpara">Sign up to see photos and videos</p>
        <div>
          <input
            type="email"
            name="email"
            id="email"
            value={email}
            onChange={(e)=>{setEmail(e.target.value)}}
            placeholder="enter you email"
          />
        </div>

        <div>
          <input
            type="text"
            name="name"
            id="name"
            value={name}
            onChange={(e)=>{setName(e.target.value)}}
            placeholder="enter you name"
          />
        </div>
        <div>
          <input
            type="text"
            name="username"
            id="username"
            value={username}
            onChange={(e)=>{setUsername(e.target.value)}}
            placeholder="enter you username"
          />
        </div>
        <div>
          <input
            type="password"
            name="password"
            id="password"
            value={password}
            onChange={(e)=>{setPassword(e.target.value)}}
            placeholder="enter you password"
          />
        </div>
        <input type='submit' id="submit-btn" value='sign up' 
        onClick={()=>{postData()}} />
      <div className="form2">
        Already have an account ?
        <Link to='/signin'>
        <span>Sign In</span>
        </Link>
       
      </div>
      </div>
      </center>
    </div>
  );
}
export default SignUp;
