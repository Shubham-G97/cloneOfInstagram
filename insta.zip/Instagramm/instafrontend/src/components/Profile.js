import React from "react";
import './Profile.css'
function Profile(){
    return (
      <div className="profile">
      {/* profile frame */}
<div className="profile-frame">
<div className="profile-pic">
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt="" />

</div>
<div className="profile-data">
<h1>Heavy coder</h1>
<div className="profile-info" style={{display:"flex"}}>
  <p>40 posts</p>
  <p>40 followers</p>
  <p>40 following</p>
</div>
</div>

</div>
<hr style={{
  width:"90%",
  margin:"25px auto",
opacity:"0.8",
}}></hr>
<div className="gallery">
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
<img src="https://motorsportmagazine.b-cdn.net/wp-content/uploads/2022/08/Oscar-Piastri-portrait.jpg" alt=""></img>
</div>
      </div>
    )
}
export default Profile