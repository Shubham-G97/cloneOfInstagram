import React from "react";
import './Home.css'
export default function Home() {
  return (
    <div className="home">
      {/* card */}
      <div className="card">
        <div className="card-header">
          <div className="card-pic">
            <img
              src="https://previews.123rf.com/images/mimagephotography/mimagephotography1511/mimagephotography151100038/48581692-close-up-portrait-horizontal-d-un-homme-s%C3%A9rieux-avec-la-barbe-isol%C3%A9-sur-fond-blanc.jpg"
              alt=""
            />
           
          </div>
          <h5>ramesh</h5>
        </div>
        <div className="card-image">
          <img
            src="https://i0.wp.com/picjumbo.com/wp-content/uploads/beautifully-stacked-pile-of-fire-wood-free-photo.jpg?w=1024&quality=50"
            alt=""
          />
        </div>
        <div className="card-content">
          <span class="material-symbols-outlined">favorite</span>
          <p>1 Like</p>
          <p>This is amazing</p>
        </div>
        <div className="add-comment">
          <span class="material-symbols-outlined">sentiment_satisfied</span>
          <input type="text" placeholder="Add a comment"></input>
          <button className="comment">Post</button>
        </div>
      </div>
    </div>
  );
}
